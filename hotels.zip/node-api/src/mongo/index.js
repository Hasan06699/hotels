import mongoose from "mongoose";
import dotenv from "dotenv";

dotenv.config();
mongoose.set('strictQuery', true);

export const dbConnect = () => {

console.log(process.env.DB_LINK,'==============')
  return mongoose.connect(
    process.env.DB_LINK
  ).then(() => {
    console.log("DB connection successful");
  }).catch((error) => {
    console.error("DB connection error:", error);
  });
};

// Call the dbConnect function to establish the database connection
