import userRoutes from './users';
import meRoutes from './me';
import authRoutes from './auth';

export { userRoutes, meRoutes, authRoutes };
