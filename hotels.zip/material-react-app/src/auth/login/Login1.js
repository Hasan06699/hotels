import React from 'react'

function Login1() {
  return (
    <div>Login1
        <h1>my name is mohd mubeen</h1>
    </div>
  )
}

export default Login1